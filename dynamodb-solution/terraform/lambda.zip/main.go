// lambda/main.go
package main

import (
	"context"
	"encoding/json"
	"log"
	"time"

	"github.com/aws/aws-lambda-go/events"
	"github.com/aws/aws-lambda-go/lambda"
)

// Order structure (must match the one from the API)
type Order struct {
	OrderID    string    `json:"order_id"`
	CustomerID int       `json:"customer_id"`
	Status     string    `json:"status"`
	CreatedAt  time.Time `json:"created_at"`
}

// This is the 3-second payment simulation
func processPayment(order Order) {
	log.Printf("LAMBDA: Processing payment for Order %s...", order.OrderID)
	time.Sleep(3 * time.Second) // The same 3-second delay
	log.Printf("LAMBDA: ...Payment complete for Order %s.", order.OrderID)
}

// handleRequest is the main Lambda handler
func handleRequest(ctx context.Context, snsEvent events.SNSEvent) {
	// An SNS event can contain multiple messages
	for _, record := range snsEvent.Records {
		snsRecord := record.SNS
		message := snsRecord.Message

		log.Printf("LAMBDA: Received message %s", record.SNS.MessageID)

		var order Order
		if err := json.Unmarshal([]byte(message), &order); err != nil {
			log.Printf("LAMBDA: ERROR: Failed to unmarshal order: %v", err)
			continue // Go to the next message
		}

		// Run the 3-second payment processing
		processPayment(order)
	}
}

func main() {
	// Start the Lambda handler
	lambda.Start(handleRequest)
}
